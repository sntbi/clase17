from setuptools import setup

setup (
    author="Santi",
    author_email="santibis2808@gmail.com",
    description="Prueba de paquete redistributible",
    version='0.0.1',
    name="mipaquete",
    packages=['matematica'] ,
)


